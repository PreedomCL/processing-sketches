This is my submission for the Intro to Programming Final "Friend Simulator"
---------------------------------------------------------------------------
Included in this .zip file are two processing sketch folders:

  Friend Simulator: The sketch that was assigned. I completed this in 22:56
  and though I include it since it was what you asked for.
  
  Gravity: This is what I worked on for the final. It is a rough gravity
  sim that is really fun to mess around with. I had a prototype of this
  sketch already made, so I decided to work more on it and improve it.
  Instructions will be on the screen upon startup. You can also check the 
  code for comments on how to operate the program.

  The gravity sim took a lot of effort so I hope you enjoy it :)